import React from 'react';
import { Search, Bell, Share2, PlusCircle, MessageSquareCode, Layers } from 'lucide-react';
import { CollectionType } from '../types';

interface HeaderProps {
  currentView: string;
  setCurrentView: (view: string) => void;
  selectedCollection: CollectionType | 'all';
  setSelectedCollection: (col: CollectionType | 'all') => void;
  onOpenAdmin: () => void;
  searchKeyword: string;
  setSearchKeyword: (keyword: string) => void;
}

export default function Header({
  currentView,
  setCurrentView,
  selectedCollection,
  setSelectedCollection,
  onOpenAdmin,
  searchKeyword,
  setSearchKeyword
}: HeaderProps) {
  return (
    <header className="sticky top-0 z-40 w-full" id="portal-header">
      {/* Top Bar with Urgent Notes */}
      <div className="bg-amber-500 text-amber-950 px-4 py-1.5 text-center text-xs font-semibold flex items-center justify-center gap-2">
        <span className="inline-flex h-2 w-2 animate-ping rounded-full bg-red-600"></span>
        <span className="font-mono tracking-wide">CONFIDENTIAL & OFFICIAL PORTAL</span>
        <span className="hidden sm:inline">| Best Education, Admit Card & Sarkari Result Hub for Bihar State & Neighbors</span>
      </div>

      {/* Main Red Brand Header */}
      <div className="bg-[#D32F2F] text-white shadow-lg px-4 py-3 sm:py-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          
          {/* Logo Brand */}
          <div 
            onClick={() => { setCurrentView('home'); setSelectedCollection('all'); }} 
            className="flex items-center gap-4 cursor-pointer group"
          >
            <div className="bg-white text-[#D32F2F] font-black text-2xl px-3.5 py-1 rounded shadow-md flex items-center justify-center transform group-hover:scale-105 transition-transform shrink-0">
              <span className="text-xl sm:text-2xl font-black font-mono tracking-tighter">RB</span>
            </div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-black tracking-tighter uppercase text-white">
                Result Bihar
              </h1>
              <p className="text-[10px] sm:text-xs text-white/80 font-mono tracking-wider uppercase font-bold">
                Bihar's #1 Premium Sarkari Portal
              </p>
            </div>
          </div>

          {/* Social Channels and Interactive Admin */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            {/* WhatsApp Link */}
            <a 
              href="https://chat.whatsapp.com/example-result-bihar-group" 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs sm:text-sm font-bold px-3 py-2 rounded-lg inline-flex items-center gap-1.5 shadow-md hover:shadow-emerald-900/30 transition-all border border-emerald-500/20"
              id="whatsapp-channel-btn"
            >
              <span className="font-sans">Join WhatsApp Channel</span>
            </a>

            {/* Telegram Link */}
            <a 
              href="https://t.me/example_result_bihar" 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-sky-600 hover:bg-sky-500 text-white text-xs sm:text-sm font-bold px-3 py-2 rounded-lg inline-flex items-center gap-1.5 shadow-md hover:shadow-sky-900/30 transition-all border border-sky-500/20"
              id="telegram-channel-btn"
            >
              <span className="font-sans">Telegram Group</span>
            </a>

            {/* Quick Content Creator Tool (Section 8 Content Workflow) */}
            <button
              onClick={onOpenAdmin}
              className="bg-amber-400 hover:bg-amber-300 text-red-950 text-xs sm:text-sm font-bold px-3 py-2 rounded-lg inline-flex items-center gap-1.5 shadow-md hover:shadow-amber-500/30 transition-all border border-amber-300"
              title="Post generator panel for jobs/results"
              id="admin-portal-trigger"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Post CMS</span>
            </button>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Strip for Quick Filters */}
      <div className="bg-neutral-900 border-b border-rose-950 text-neutral-200 px-4 py-2 text-xs sm:text-sm overflow-x-auto whitespace-nowrap scrollbar-none flex items-center justify-between">
        <div className="max-w-7xl mx-auto w-full flex items-center justify-between gap-4">
          <div className="flex items-center gap-1.5 sm:gap-2">
            <button
              onClick={() => { setCurrentView('home'); setSelectedCollection('all'); }}
              className={`px-3 py-1.5 rounded-md font-medium transition-all ${
                currentView === 'home' && selectedCollection === 'all'
                  ? 'bg-rose-700 text-white shadow-inner font-semibold'
                  : 'hover:bg-neutral-800 hover:text-white'
              }`}
            >
              Home Hub
            </button>
            <div className="h-4 w-[1px] bg-neutral-700"></div>
            
            {/* Collection Navigation Buttons */}
            {[
              { id: 'jobs', label: 'Jobs' },
              { id: 'results', label: 'Results' },
              { id: 'admit-cards', label: 'Admit Cards' },
              { id: 'answer-keys', label: 'Answer Keys' },
              { id: 'admissions', label: 'Admissions' },
              { id: 'syllabus', label: 'Syllabus' },
              { id: 'scholarships', label: 'Scholarships' },
              { id: 'yojana', label: 'Yojana' }
            ].map((col) => (
              <button
                key={col.id}
                onClick={() => {
                  setCurrentView('home');
                  setSelectedCollection(col.id as CollectionType);
                }}
                className={`px-2.5 py-1.5 rounded-md transition-all text-xs font-medium ${
                  currentView === 'home' && selectedCollection === col.id
                    ? 'bg-amber-500 text-neutral-950 font-semibold shadow-inner'
                    : 'hover:bg-neutral-800 hover:text-white'
                }`}
              >
                {col.label}
              </button>
            ))}
          </div>

          <div className="hidden lg:flex items-center gap-1.5 text-neutral-400 text-xs">
            <Layers className="w-3.5 h-3.5 text-amber-500" />
            <span>Updated live: {new Date().toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
          </div>
        </div>
      </div>
    </header>
  );
}
